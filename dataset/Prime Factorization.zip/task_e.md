**Prime Factorization**

**Problem Description**

The positive integer N is the product of two different primes, try to find the larger one.

**Input**

There is only one line that contains a positive integer n (less than 2×10^9^).

**Output**

There is only one line that contains a positive integer p, that is, the larger prime.

**Sample Input**

21

**Sample Output**

7
